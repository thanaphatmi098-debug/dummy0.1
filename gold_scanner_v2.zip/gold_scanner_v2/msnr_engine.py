import numpy as np

def _pivots(df, width=3):
    highs, lows = [], []
    h, l = df.high.to_numpy(), df.low.to_numpy()
    for i in range(width, len(df)-width):
        window_h = h[i-width:i+width+1]
        window_l = l[i-width:i+width+1]
        if h[i] == window_h.max() and np.sum(window_h == h[i]) == 1:
            highs.append((i, float(h[i]), float(df.close.iloc[i])))
        if l[i] == window_l.min() and np.sum(window_l == l[i]) == 1:
            lows.append((i, float(l[i]), float(df.close.iloc[i])))
    return highs, lows

def analyze_msnr(df):
    """QM close-level approximation + staircase/double-breakout level."""
    d = df.iloc[:-1].copy()
    if len(d) < 35:
        return {}
    highs, lows = _pivots(d)
    close = float(d.close.iloc[-1])
    out = {"qm_resistance": None, "qm_support": None,
           "double_break_bull": False, "double_break_bear": False,
           "staircase_high": None, "staircase_low": None}

    # QM: close-based level from consecutive pivot sequence; approximation pending exact source script.
    if len(highs) >= 2 and len(lows) >= 2:
        h1, h2 = highs[-2], highs[-1]
        l1, l2 = lows[-2], lows[-1]
        # bearish QM: higher high followed by lower low; level is prior pivot close.
        # Bearish sequence: higher high forms, then the later swing low breaks lower.
        if h2[1] > h1[1] and l2[1] < l1[1] and h2[0] < l2[0]:
            out["qm_resistance"] = h1[2]
        # Bullish sequence: lower low forms, then the later swing high breaks higher.
        if l2[1] < l1[1] and h2[1] > h1[1] and l2[0] < h2[0]:
            out["qm_support"] = l1[2]

    # Staircase of turning points: at least 3 progressively higher highs/lows or lower highs/lows.
    if len(highs) >= 3 and len(lows) >= 3:
        hs = [x[1] for x in highs[-3:]]
        ls = [x[1] for x in lows[-3:]]
        out["staircase_high"] = max(hs)
        out["staircase_low"] = min(ls)
        if all(hs[i] > hs[i-1] for i in range(1, 3)) and all(ls[i] > ls[i-1] for i in range(1, 3)):
            out["double_break_bull"] = close > max(hs)
        if all(hs[i] < hs[i-1] for i in range(1, 3)) and all(ls[i] < ls[i-1] for i in range(1, 3)):
            out["double_break_bear"] = close < min(ls)
    return out
