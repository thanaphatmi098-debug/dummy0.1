import numpy as np

def _swings(df, left=3, right=3):
    highs, lows = [], []
    h = df["high"].to_numpy()
    l = df["low"].to_numpy()
    for i in range(left, len(df) - right):
        if h[i] >= np.max(h[i-left:i+right+1]) and np.sum(h[i] == h[i-left:i+right+1]) == 1:
            highs.append((i, float(h[i])))
        if l[i] <= np.min(l[i-left:i+right+1]) and np.sum(l[i] == l[i-left:i+right+1]) == 1:
            lows.append((i, float(l[i])))
    return highs, lows

def analyze_smc(df):
    """Closed-candle SMC heuristics. Returns facts, not guaranteed trade signals."""
    d = df.iloc[:-1].copy()  # ignore potentially forming candle
    if len(d) < 30:
        return {}
    highs, lows = _swings(d)
    last = d.iloc[-1]
    prev = d.iloc[-2]
    close = float(last.close)
    result = {
        "bos_bull": False, "bos_bear": False,
        "mss_bull": False, "mss_bear": False,
        "sweep_bull": False, "sweep_bear": False,
        "bull_ob": None, "bear_ob": None,
        "bull_fvg": None, "bear_fvg": None,
        "bull_ifvg": False, "bear_ifvg": False,
        "premium_discount": "equilibrium",
        "last_close": close,
    }

    recent_highs = [(i, p) for i, p in highs if i < len(d)-2]
    recent_lows = [(i, p) for i, p in lows if i < len(d)-2]
    if recent_highs:
        sh = recent_highs[-1][1]
        result["bos_bull"] = close > sh
        result["sweep_bear"] = float(last.high) > sh and close < sh
    if recent_lows:
        sl = recent_lows[-1][1]
        result["bos_bear"] = close < sl
        result["sweep_bull"] = float(last.low) < sl and close > sl

    # MSS proxy: close breaks latest opposing swing after prior candle did not.
    result["mss_bull"] = bool(recent_highs and close > recent_highs[-1][1] and float(prev.close) <= recent_highs[-1][1])
    result["mss_bear"] = bool(recent_lows and close < recent_lows[-1][1] and float(prev.close) >= recent_lows[-1][1])

    # Order block proxy: last opposite candle before a strong displacement candle.
    atr = (d.high - d.low).rolling(14).mean().iloc[-1]
    if atr and np.isfinite(atr):
        for i in range(len(d)-2, max(2, len(d)-25), -1):
            c = d.iloc[i+1]
            p = d.iloc[i]
            body = abs(float(c.close) - float(c.open))
            if body >= 1.2 * atr and c.close > c.open and p.close < p.open:
                result["bull_ob"] = [float(p.low), float(p.high)]
                break
        for i in range(len(d)-2, max(2, len(d)-25), -1):
            c = d.iloc[i+1]
            p = d.iloc[i]
            body = abs(float(c.close) - float(c.open))
            if body >= 1.2 * atr and c.close < c.open and p.close > p.open:
                result["bear_ob"] = [float(p.low), float(p.high)]
                break

    # Three-candle fair value gaps.
    for i in range(len(d)-1, 1, -1):
        a, c = d.iloc[i-2], d.iloc[i]
        if float(c.low) > float(a.high):
            result["bull_fvg"] = [float(a.high), float(c.low)]
            break
        if float(c.high) < float(a.low):
            result["bear_fvg"] = [float(c.high), float(a.low)]
            break

    # IFVG proxy: price closes through the latest opposite FVG boundary.
    if result["bear_fvg"]:
        result["bull_ifvg"] = close > result["bear_fvg"][1]
    if result["bull_fvg"]:
        result["bear_ifvg"] = close < result["bull_fvg"][0]

    # Dealing range based on latest 20 completed candles.
    hi, lo = float(d.high.tail(20).max()), float(d.low.tail(20).min())
    mid = (hi + lo) / 2
    result["premium_discount"] = "discount" if close < mid else "premium" if close > mid else "equilibrium"
    result["range"] = [lo, hi]
    return result
