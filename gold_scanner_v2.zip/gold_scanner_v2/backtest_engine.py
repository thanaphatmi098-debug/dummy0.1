"""Basic research harness. It deliberately avoids claiming live profitability."""
from market_data import fetch_candles
from smc_engine import analyze_smc
from msnr_engine import analyze_msnr

def inspect_latest():
    data = fetch_candles()
    for tf, df in data.items():
        print("\\n", tf)
        print("SMC:", analyze_smc(df))
        print("MSNR:", analyze_msnr(df))

if __name__ == "__main__":
    inspect_latest()
