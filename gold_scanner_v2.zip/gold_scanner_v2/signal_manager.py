import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

STATE_FILE = Path("scans/last_signal.json")

def is_new_signal(signal, symbol):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha256(json.dumps(
        {"symbol": symbol, "side": signal["side"], "score": signal["score"],
         "reasons": signal["reasons"]}, sort_keys=True).encode()).hexdigest()
    old = None
    if STATE_FILE.exists():
        try: old = json.loads(STATE_FILE.read_text())
        except Exception: old = None
    if old and old.get("key") == key:
        return False
    STATE_FILE.write_text(json.dumps({
        "key": key, "symbol": symbol, "signal": signal,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }, indent=2))
    return True
