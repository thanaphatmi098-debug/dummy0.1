import requests
import pandas as pd
from config import API_KEY, SYMBOL, TIMEFRAMES

BASE_URL = "https://api.twelvedata.com/time_series"

def fetch_candles(symbol=SYMBOL, timeout=20):
    if not API_KEY:
        raise RuntimeError("Missing TWELVEDATA_API_KEY")
    result = {}
    for tf, (interval, outputsize) in TIMEFRAMES.items():
        response = requests.get(
            BASE_URL,
            params={
                "symbol": symbol,
                "interval": interval,
                "outputsize": outputsize,
                "apikey": API_KEY,
                "timezone": "UTC",
                "order": "ASC",
            },
            timeout=timeout,
        )
        response.raise_for_status()
        payload = response.json()
        if "values" not in payload:
            raise RuntimeError(f"Twelve Data {tf} error: {payload.get('message', payload)}")
        df = pd.DataFrame(payload["values"])
        df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
        for col in ("open", "high", "low", "close"):
            df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df.dropna(subset=["datetime", "open", "high", "low", "close"])
        df = df.sort_values("datetime").drop_duplicates("datetime").reset_index(drop=True)
        if len(df) < 40:
            raise RuntimeError(f"Not enough {tf} candles: {len(df)}")
        result[tf] = df
    return result
