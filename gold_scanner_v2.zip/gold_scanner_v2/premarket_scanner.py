import argparse
from config import SYMBOL, MIN_SCORE
from market_data import fetch_candles
from mtf_analyzer import analyze_all, build_signal
from signal_manager import is_new_signal
from notifier import send_telegram, format_message

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-telegram", action="store_true")
    args = parser.parse_args()
    if args.test_telegram:
        send_telegram("Gold Scanner v2: Telegram test OK")
        return
    data = fetch_candles()
    analysis = analyze_all(data)
    signal = build_signal(analysis, MIN_SCORE)
    print({"symbol": SYMBOL, "signal": signal})
    if signal["side"] != "NO SIGNAL" and is_new_signal(signal, SYMBOL):
        send_telegram(format_message(SYMBOL, signal, analysis))

if __name__ == "__main__":
    main()
