from smc_engine import analyze_smc
from msnr_engine import analyze_msnr

def analyze_all(data):
    return {
        tf: {"smc": analyze_smc(df), "msnr": analyze_msnr(df)}
        for tf, df in data.items()
    }

def build_signal(analysis, min_score=7):
    """Confluence score. Signals are alerts for review, not trade instructions."""
    score_buy = score_sell = 0
    reasons_buy, reasons_sell = [], []

    # Big-picture direction: D1/H4/H1 agreement carries more weight.
    for tf, weight in (("D1", 2), ("H4", 2), ("H1", 1)):
        a = analysis.get(tf, {})
        s, m = a.get("smc", {}), a.get("msnr", {})
        if s.get("bos_bull") or s.get("mss_bull") or m.get("double_break_bull"):
            score_buy += weight; reasons_buy.append(f"{tf}: bullish structure")
        if s.get("bos_bear") or s.get("mss_bear") or m.get("double_break_bear"):
            score_sell += weight; reasons_sell.append(f"{tf}: bearish structure")

    # Pullback/context M15
    a = analysis.get("M15", {})
    s, m = a.get("smc", {}), a.get("msnr", {})
    if s.get("sweep_bull"): score_buy += 2; reasons_buy.append("M15: sell-side liquidity sweep")
    if s.get("sweep_bear"): score_sell += 2; reasons_sell.append("M15: buy-side liquidity sweep")
    if s.get("bull_ob") or s.get("bull_fvg") or m.get("qm_support"): score_buy += 1; reasons_buy.append("M15: bullish OB/FVG/QM context")
    if s.get("bear_ob") or s.get("bear_fvg") or m.get("qm_resistance"): score_sell += 1; reasons_sell.append("M15: bearish OB/FVG/QM context")

    # Entry confirmation M5
    a = analysis.get("M5", {})
    s, m = a.get("smc", {}), a.get("msnr", {})
    if s.get("mss_bull") or s.get("bull_ifvg") or m.get("double_break_bull"):
        score_buy += 2; reasons_buy.append("M5: bullish MSS/IFVG/MSnR confirmation")
    if s.get("mss_bear") or s.get("bear_ifvg") or m.get("double_break_bear"):
        score_sell += 2; reasons_sell.append("M5: bearish MSS/IFVG/MSnR confirmation")

    if score_buy >= min_score and score_buy > score_sell:
        side, score, reasons = "BUY WATCH", score_buy, reasons_buy
    elif score_sell >= min_score and score_sell > score_buy:
        side, score, reasons = "SELL WATCH", score_sell, reasons_sell
    else:
        side, score, reasons = "NO SIGNAL", max(score_buy, score_sell), []
    return {"side": side, "score": score, "buy_score": score_buy,
            "sell_score": score_sell, "reasons": reasons}
