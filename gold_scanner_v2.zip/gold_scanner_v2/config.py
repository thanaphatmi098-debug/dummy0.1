import os

SYMBOL = os.getenv("SCAN_SYMBOL", "XAU/USD")
API_KEY = os.getenv("TWELVEDATA_API_KEY", "")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# Twelve Data intervals: daily, 4h, 1h, 15min, 5min
TIMEFRAMES = {
    "D1": ("1day", 180),
    "H4": ("4h", 240),
    "H1": ("1h", 300),
    "M15": ("15min", 300),
    "M5": ("5min", 300),
}
MIN_SCORE = int(os.getenv("MIN_SCORE", "7"))
