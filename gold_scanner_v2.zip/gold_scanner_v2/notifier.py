import requests
from config import TELEGRAM_TOKEN, TELEGRAM_CHAT_ID

def send_telegram(message):
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        print("Telegram not configured; message follows:")
        print(message)
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    response = requests.post(url, data={
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "disable_web_page_preview": True,
    }, timeout=20)
    response.raise_for_status()
    payload = response.json()
    if not payload.get("ok"):
        raise RuntimeError(f"Telegram error: {payload}")

def format_message(symbol, signal, analysis):
    lines = [
        f"Gold Scanner v2 | {symbol}",
        f"สถานะ: {signal['side']}",
        f"Confluence: {signal['score']} | BUY {signal['buy_score']} / SELL {signal['sell_score']}",
        "",
        "เหตุผล:"
    ]
    lines += [f"- {x}" for x in signal["reasons"]] or ["- เงื่อนไขยังไม่ครบ"]
    lines += ["", "ราคาปิดล่าสุดตาม TF:"]
    for tf in ("D1", "H4", "H1", "M15", "M5"):
        smc = analysis.get(tf, {}).get("smc", {})
        if smc.get("last_close") is not None:
            lines.append(f"- {tf}: {smc['last_close']}")
    lines += ["", "หมายเหตุ: เป็นสัญญาณเฝ้าระวังจากแท่งที่ปิดแล้ว ไม่ใช่คำสั่งซื้อขาย"]
    return "\\n".join(lines)
